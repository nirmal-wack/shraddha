export const ImagesAssets: { [key: string]: any } = {
    google: require('./google.png'),
    facebook: require('./Facebook.png'),
    twitter: require('./xtwitter.png'),
    logo: require('./edu_logo.jpg'),
};