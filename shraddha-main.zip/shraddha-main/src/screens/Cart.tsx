import React, { Component } from 'react'
import { Text, View } from 'react-native'

export class Cart extends Component {
  render() {
    return (
      <View>
        <Text> CartPage </Text>
      </View>
    )
  }
}

export default Cart
