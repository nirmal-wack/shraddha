import React, { Component } from 'react'
import { Text, View } from 'react-native'

export class Profile extends Component {
  render() {
    return (
      <View>
        <Text> ProfilePage </Text>
      </View>
    )
  }
}

export default Profile
