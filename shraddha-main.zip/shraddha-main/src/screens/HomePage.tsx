import React, { Component } from 'react'
import { Text, View } from 'react-native'

export class HomePage extends Component {
  render() {
    return (
      <View>
        <Text> HomePage </Text>
      </View>
    )
  }
}

export default HomePage
